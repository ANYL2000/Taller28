<?php


$modal = "<div class='modal' style='position:absolute;z-index:20;' tabindex='-1' role='dialog'>
<div class='modal-dialog' role='document'>
  <div class='modal-content'>
    <div class='modal-header'>
      <h5 class='modal-title'>Tiempo excedido</h5>
      <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
        <span aria-hidden='true'>&times;</span>
      </button>
    </div>
    <div class='modal-body'>
      <p>Debe de iniciar sesión de nuevo</p>
    </div>
    <div class='modal-footer'>
      <button type='button' class='btn btn-primary'>Ok</button>
     
    </div>
  </div>
</div>
</div>";

echo $modal;

?>
