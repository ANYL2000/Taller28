<?php

require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion


if(!isset($_SESSION['login_user_sys'])){

  //mysqli_close($conexion); // Cerrando la conexion
  echo "<script type='text/javascript'>
        window.location='sesion.php'
        </script>"; // Redirecciona a la pagina de sesion
  }else{
    $usuario = $_SESSION['login_user_sys'];
  }


$tallerista_seleccionado = $_GET['tallerista'];
 $taller_seleccionado = $_GET["taller"];
 $calendario_seleccionado = $_GET['calendario'];
 $turno_seleccionado = $_GET['turno'];
$dia_seleccionado = $_GET['dia'];
$id_obtenido = $_GET['id'];
$enviar_correo = $_GET['enviar'];



$conexion = mysqli_connect($host, $db_username, $db_password,$db_name );
$conexion->query("SET NAMES 'utf8'");
$validar_talleres = "SELECT * FROM mostrar_talleres WHERE Calendario = '$calendario_seleccionado' AND 
NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
Dia = '$dia_seleccionado'";

$fila_talleres = mysqli_query($conexion,$validar_talleres);

if(mysqli_num_rows($fila_talleres)==0){
  
  echo "<script type='text/javascript'>
  window.location='taller1.1.php'
  </script>";
}

if(empty($id_obtenido)){
  echo "<script>window.location='taller1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado';</script>";

}

while($fila = mysqli_fetch_array($fila_talleres)){ 
    $Fecha_inicio = $fila['Fecha_inicio'];
    $Fecha_final = $fila['Fecha_final'];
    $Fecha_constancia_generada = $fila['Fecha_constancia_generada'];
}


date_default_timezone_set('America/Mexico_City');   

$hoy = $Fecha_constancia_generada;

$arr0 = explode('-', $hoy);
$newDate0 = $arr0[2].'-'.$arr0[1].'-'.$arr0[0];


$m0 = "";
switch($arr0[1]){

  case '01':   $m0 = "Enero";     break;
  case '02':  $m0 = "Febrero";      break;
  case '03':  $m0 = "Marzo";      break;
  case '04':  $m0 = "Abril";      break;
  case '05':  $m0 = "Mayo";      break;
  case '06':  $m0 = "Junio";      break;
  case '07':  $m0 = "Julio";      break;
  case '08':  $m0 = "Agosto";      break;
  case '09':  $m0 = "Septiembre";      break;
  case '10':  $m0 = "Octubre";      break;
  case '11':   $m0 = "Noviembre";     break;
  case '12':   $m0 = "Diciembre";     break;

}

$fecha_hoy = $arr0[2].' de '.$m0.' del '.$arr0[0];



//se inicia el cambio de fecha a texto normal para imprimir
$arr1 = explode('-', $Fecha_inicio);
$newDate1 = $arr1[2].'-'.$arr1[1].'-'.$arr1[0];


$m1 = "";
switch($arr1[1]){

  case '01':   $m1 = "Enero";     break;
  case '02':  $m1 = "Febrero";      break;
  case '03':  $m1 = "Marzo";      break;
  case '04':  $m1 = "Abril";      break;
  case '05':  $m1 = "Mayo";      break;
  case '06':  $m1 = "Junio";      break;
  case '07':  $m1 = "Julio";      break;
  case '08':  $m1 = "Agosto";      break;
  case '09':  $m1 = "Septiembre";      break;
  case '10':  $m1 = "Octubre";      break;
  case '11':   $m1 = "Noviembre";     break;
  case '12':   $m1 = "Diciembre";     break;

}

//convertir formato de fecha final
$arr2 = explode('-', $Fecha_final);
$newDate2 = $arr2[2].'-'.$arr2[1].'-'.$arr2[0];


$m2 = "";
switch($arr2[1]){

  case '01':   $m2 = "Enero";     break;
  case '02':  $m2 = "Febrero";      break;
  case '03':  $m2 = "Marzo";      break;
  case '04':  $m2 = "Abril";      break;
  case '05':  $m2 = "Mayo";      break;
  case '06':  $m2 = "Junio";      break;
  case '07':  $m2 = "Julio";      break;
  case '08':  $m2 = "Agosto";      break;
  case '09':  $m2 = "Septiembre";      break;
  case '10':  $m2 = "Octubre";      break;
  case '11':   $m2 = "Noviembre";     break;
  case '12':   $m2 = "Diciembre";     break;

}

$fecha_texto = $arr1[2].' de '.$m1.' del '.$arr1[0].' al '.$arr2[2].' de '.$m2.' del '.$arr2[0];





$sql = "SELECT * FROM constancias_alumnos WHERE idUsuarios=$id_obtenido AND NombreTallerista = '$tallerista_seleccionado' AND NombreTaller = '$taller_seleccionado' AND Ingreso = '$calendario_seleccionado' AND Turno = '$turno_seleccionado' AND Dia = '$dia_seleccionado' ;";

$result = mysqli_query($conexion,$sql);

if(mysqli_num_rows($result)==0){
  
    echo "<script type='text/javascript'>
    window.location='taller1.1.php'
    </script>";
  }

  ob_start();

?>

<!DOCTYPE html>
<html >
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
<title>Constancias PDF</title>
</header>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body >


<img  src="http://<?php echo $_SERVER['HTTP_HOST'];?>/Talleres/assets/img/constancias_fondo2.png" style="position:absolute; top:-5%;left:-6%;z-index:-10;" alt="http://<?php echo $_SERVER['HTTP_HOST'];?>/Talleres/assets/img/constancias_fondo.png">
<?php  while($alumno = mysqli_fetch_array($result)){ 
   $nombre_alumno = $alumno['Nombre'];
   $nombre_taller = $alumno['NombreTaller'];
   $ciclo_taller = $alumno['Ingreso'];
   $correo = $alumno['Correo'];
   $turno = $alumno['Turno'];
   $dia = $alumno['Dia'];
  ?>

<h5 style="position: absolute;right:3%;font-family: Arial, Helvetica, sans-serif;">Folio:<?php echo '<text style="color:#00A19A;"> '.$alumno['Folio'].'</text>'; ?></h5>

<h4 style="position:relative; top:48%;text-align: center;color:#00A19A;font-family: Arial, Helvetica, sans-serif;">A:<?php echo ' '.$alumno['Nombre'];?></h4>
<div style="position:relative; top:52%;color: rgb(75, 75, 75);text-align: center;font-family: Arial, Helvetica, sans-serif;">

<h5>Con código<?php echo '<text style="font-weight:bold;color:black;"> '.$alumno['Codigo'].' </text>';?>de la carrera de </h5>
<h5><?php echo ' '.$alumno['Carrera'].' '?>, por su participación</h5>
<h5>en el Taller de <?php  echo ' '.$alumno['NombreTaller'].' '?>realizado en este </h5>
<h5>Centro Universitario del <?php echo ' '.$fecha_texto.' '?></h5>
</div>

<div style="position:relative; top:54%;color: rgb(70, 70, 70);font-size:13px;text-align: center;font-family: Arial, Helvetica, sans-serif;">
<p>Atentamente</p>
<p style="position: relative;top:-15px;">"Piensa y Trabaja"</p>
<p style="position: relative;top:-28px;">Tepatitlán de Morelos, Jal,<?php echo ' '.$fecha_hoy;?></p>
</div>

<div style="position:relative;top:61%;left:30%;border-top:2px solid black;width: 40%;font-size:16px;text-align: center;font-family: Arial, Helvetica, sans-serif;">
<p ><?php echo '<text style="color:#00A19A;">Lic. Rosaura Saldaña Ríos</text>'?><?php echo '<br><text style="font-size:13px;">Coordinadora de Extensión</text>'?></p>
</div>

<?php  }  ?>

</body>
</html>



<?php 
$html=ob_get_clean();

//echo $html;
require_once '../assets/libreria/dompdf/autoload.inc.php';
include '../assets/libreria/PHPMailer/src/PHPMailer.php';
include '../assets/libreria/PHPMailer/src/Exception.php';
include '../assets/libreria/PHPMailer/src/SMTP.php';
use \Dompdf\Dompdf;

$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled' => true));

$dompdf->setOptions($options);

$dompdf->loadHtml($html);

$dompdf->setPaper('letter');
$dompdf->render();
$nombre_archivo="Constancia_";
$nombre_archivo.=$nombre_taller.'_'.$ciclo_taller.'_'.$turno.'_'.$dia.'_';
$nombre_archivo.=$nombre_alumno;
$nombre_archivo.=".pdf";

if($enviar_correo=="No"){
$dompdf->stream($nombre_archivo,array("Attachment" => false));
}else if ($enviar_correo=='Si'){

file_put_contents('../assets/Constancias/'.$nombre_archivo, $dompdf->output()); //se guarda el pdf en una direccion

//--------------------------------------------------------
//bloque para consultar la cuenta del remitente en la base de datos
$validar_cuenta_remitente = "SELECT Correo,(cast(aes_decrypt(Contra,'CUALTOS1234567890') as char))  FROM correo_remitente";

$fila_cuenta_remitente = mysqli_query($conexion,$validar_cuenta_remitente);

$entrar_a_enviar = true;

if(mysqli_num_rows($fila_cuenta_remitente)>0){ //valida si encontro una cuenta

  $cuenta = mysqli_fetch_array($fila_cuenta_remitente);
 

}else{
  $cuenta[0] = "";
  $cuenta[1] = "";
  $entrar_a_enviar = false;
  echo '<script> alert("Debe de registrar primero la cuenta del remitente para poder enviar correos"); </script>';
}

if($entrar_a_enviar==true){
//--------------------------------------------------------------------

$mail = new PHPMailer\PHPMailer\PHPMailer();
    try {

    
       
    //Server settings
   $mail->SMTPDebug = 0;                      // Enable verbose debug output
   $mail->isSMTP();                                            // Send using SMTP
   $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
   $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
   $mail->SMTPSecure = "tls";  
   $mail->CharSet = 'UTF-8';
   $mail->Username   = $cuenta[0];                     // SMTP username
   $mail->Password   = $cuenta[1];                               // SMTP password
   $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;       //PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
   $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
                               // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom($cuenta[0], 'Unidad de Deportes');
        $mail->addAddress($correo,$nombre_alumno);     // Add a recipient
    
        // Attachments
         $mail->addAttachment('../assets/Constancias/'.$nombre_archivo);         // Add attachments
        //$mail->addAttachment($output, 'aplication/pdf', 'factura_de_venta_No_'.$no_factura.'.pdf', false);    // Optional name
    
        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Constancia Taller: '.$taller_seleccionado.' Calendario: '.$calendario_seleccionado.' Turno: '.$turno.' Dia: '.$dia;
        $mail->Body    = 'Felicidades '.$nombre_alumno;
    
        $mail->send();

        echo '<script>
        alert(mensaje enviado correctamente);
        </script>';
       
        $files = glob('../assets/Constancias/*'); //obtenemos todos los nombres de los ficheros
foreach($files as $file){
    if(is_file($file))
    unlink($file); //elimino el fichero
}



    }
    catch(phpmailerException $ex)
    {
        echo '<script>alert("Ha ocurrido un error "'.$ex.');</script>';
    }
  }
  if($usuario=='Prestador'){
    echo "<script>window.location='constancias_servicio_social.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado&fecha_inicio=$Fecha_inicio&fecha_final=$Fecha_final';</script>";
  
  
  }else if($usuario=='Administrador'){
  echo "<script>window.location='constancias.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado&fecha_inicio=$Fecha_inicio&fecha_final=$Fecha_final';</script>";
  }
} 
$conexion=null; 
?>