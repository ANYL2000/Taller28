<?php
include('../assets/conexion/servidor.php');

$con=mysqli_connect($host,$db_username,$db_password,$db_name);
$con->query("SET NAMES 'utf8'");

$calendario = $_POST["buscar"];


$consulta_existencia = "SELECT * FROM mostrar_talleres WHERE Calendario= '$calendario'";

$filas = mysqli_query($con,$consulta_existencia);

$salida= "";
if(mysqli_num_rows($filas)>0){
    $salida.='<br>';
    $salida.='<span style="position: relative; left:40px;">Resultados encontrados:</span>';
    $salida.='<br>';
   $salida.='<table class="table-responsive">
   <thead>
<tr class="fila_principal">

   <td>Nombre del taller</td>
   <td>Calendario</td>
   <td>Capacidad</td>
   <td>Turno</td>
   <td>Tipo</td>
   <td>Dia</td>
   <td>Registrados</td>
   <td>Faltantes</td>
</tr>
</thead>';
    while($taller = mysqli_fetch_array($filas)){

$salida.='<tr class="filas_secundarias calendario_encontrado" id="color_filas" >
<td> <a href="constancias_servicio_social.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'&fecha_inicio='.$taller['Fecha_inicio'].'&fecha_final='.$taller['Fecha_final'].'">'.$taller['NombreTaller'].'</a></td>
<td> <a href="constancias_servicio_social.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'&fecha_inicio='.$taller['Fecha_inicio'].'&fecha_final='.$taller['Fecha_final'].'">'.$taller['Calendario'].'</a></td>
<td> <a href="constancias_servicio_social.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'&fecha_inicio='.$taller['Fecha_inicio'].'&fecha_final='.$taller['Fecha_final'].'">'.$taller['Capacidad'].'</a></td>
<td> <a href="constancias_servicio_social.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'&fecha_inicio='.$taller['Fecha_inicio'].'&fecha_final='.$taller['Fecha_final'].'">'.$taller['Turno'].'</a></td>
<td> <a href="constancias_servicio_social.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'&fecha_inicio='.$taller['Fecha_inicio'].'&fecha_final='.$taller['Fecha_final'].'">'.$taller['Tipo'].'</a></td>
<td> <a href="constancias_servicio_social.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'&fecha_inicio='.$taller['Fecha_inicio'].'&fecha_final='.$taller['Fecha_final'].'">'.$taller['Dia'].'</a></td>
<td> <a href="constancias_servicio_social.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'&fecha_inicio='.$taller['Fecha_inicio'].'&fecha_final='.$taller['Fecha_final'].'">'.$taller['Registrados'].'</a></td>
<td> <a href="constancias_servicio_social.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'&fecha_inicio='.$taller['Fecha_inicio'].'&fecha_final='.$taller['Fecha_final'].'">'.$taller['Lugares_Faltantes'].'</a></td>
<td><a  href="lista_pdf.php?tallerista='.$taller['NombreTallerista'].'&taller='.$taller['NombreTaller'].'&calendario='.$taller['Calendario'].'&turno='.$taller['Turno'].'&dia='.$taller['Dia'].'"><button type="submit" class="btn btn-primary">Lista</button></a></td>
</tr>';


    }
   $salida.='</table>';
   $salida.='<br><br><br>';
}else{
    $salida.="Sin resultados"; 
}

echo $salida;

?>