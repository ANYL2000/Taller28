<?php
require_once '../assets/conexion/servidor.php';


$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$conexion->query("SET NAMES 'utf8'");
$con=mysqli_connect($host,$db_username,$db_password,$db_name);
$con->query("SET NAMES 'utf8'");
$query =$conexion->prepare("SELECT * FROM calendario;");


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Talleres</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_folios_talleres.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">


<?php include 'header_taller.php'; ?>


</head>
<body>
    


<div class="fondo">

<h1 class="titulo_taller">Buscar folios</h1>

<div class="input-group" style="width:215px; position:relative; left:30px;">
              <label for="" id="labelbuscar_calendario" style="display:flex;"> 
              <input style="border: 1px solid gray;" id="buscar_folio" name = "buscar_folio"  type="text" Class="form-control" placeholder=" ">
              <span id="spanbuscar_calendario">Buscar por Folio</span>   
            
                 <div class="input-group-append">
               <button id="btnbuscar_folio" class="btn btn-primary" type="button" > <span class="fa-solid fa-magnifying-glass"></span> </button>
               </div>
               </label>
</div>

              
              <div id="datos_buscar_folio">

</div>

</div>


<script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="../assets/js/Buscar.js"></script>

</body>
</html>
<?php $con->close(); $conexion=null; ?>