<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
 
    <style>

form {
display:flex;
}

    input
    {
        font-family: Verdana;
        font-size: 12;
        color: #000000;
        border-width: 0;
        background-color: #f7f7fa;
        text-align: right;
        padding:2px;

        margin:3px;
    }
    </style>
 
</head>
 
<body>
 
<!--formulario deshabilitado donde se muestran los datos-->
<form name="form">
    <div></div><br>
    <input type="text" size="5" name="year" hidden="true" disabled> <br>
    <input type="text" size="5" name="month" hidden="true" disabled> <br>
    <input type="text" size="5" name="day" disabled> dias<br>
    <input type="text" size="5" name="hour" disabled> horas<br>
    <input type="text" size="5" name="minute" disabled> minutos<br>
    <input type="text" size="5" name="second" disabled> segundos<br>
</form>
 
</body>
</html>
 
<script>
//Codigo que muestra la cuenta atras hasta el final del año 2010
//La Web del Programador
//http://www.lawebdelprogramador.com
 
(function(){
    //variables que determinan la fecha y hora final de la cuenta atras
    let toYear=2022;
    let toMonth=11;
    let toDay=8;
    let toHour=16;
    let toMinute=22;
    let toSecond=0;
 
    const fillZero = i => i.toString().length==1 ? "0"+i : i;
 
    document.querySelector("form>div").innerHTML=`Tiempo restante hasta el ${fillZero(toDay)}-${fillZero(toMonth)}-${toYear} ${fillZero(toHour)}:${fillZero(toMinute)}:${fillZero(toSecond)}`;
    function countDown()
    {
        const actual_date=new Date();
 
        let new_second=toSecond-actual_date.getSeconds();
        let new_minute=toMinute-actual_date.getMinutes();
        let new_hour=toHour-actual_date.getHours();
        let new_day=toDay-actual_date.getDate();
        let new_month=toMonth-(1+actual_date.getMonth());
        let new_year=toYear-actual_date.getFullYear();
 
        if (new_second<0) {
            new_second=60+new_second;
            new_minute--;
        }
        if (new_minute<0) {
            new_minute=60+new_minute;
            new_hour--;
        }
        if (new_hour<0) {
            new_hour=24+new_hour;
            new_day--;
        }
        if (new_day<0) {
            new_month--;
            let m=actual_date.getMonth();
            if (m in [0, 2, 4, 6, 7, 9, 11]) {
                new_day=31+new_day;
            }
            if (m in [3, 5, 8, 10]) {
                new_day=30+new_day;
            }
            if (m==1) { //febrero
                //comprobamos si es un año bisiesto...
                if (actual_date.getYear()/4-Math.floor(actual_date.getYear()/4)==0) {
                    actual_date=29+actual_date;
                } else {
                    actual_date=28+actual_date;
                }
            }
        }
        if (new_month<0) {
            new_month=12+new_month;
            new_year--;
        }
        if (new_year<0) {
            clearInterval(interval);
            return;
        }
         //se imprime el contador
        form.second.value=fillZero(new_second);
        form.minute.value=fillZero(new_minute);
        form.hour.value=fillZero(new_hour);
        form.day.value=new_day;
        form.month.value=new_month;
        form.year.value=new_year;

        if(new_second==00&&new_minute==0&&new_hour==0&&new_day==0&&new_month==0&&new_year==0){

alert("se acabó el tiempo");

window.location='sesion.php';

}

    }
 
  

    let interval=setInterval(countDown, 1000);
   
   


})();
</script>